vim.lsp.enable("rust_analyzer")
vim.lsp.enable("clangd")
vim.lsp.enable("intelephense")

-- TODO: fix gleam ls
vim.lsp.enable("gleam")

vim.lsp.enable("gopls")
vim.lsp.enable("nil_ls")

vim.lsp.enable("cssls")
vim.lsp.enable("bashls")

vim.lsp.enable("taplo")

vim.lsp.enable("ruff")
