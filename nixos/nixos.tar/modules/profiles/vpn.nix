{...}: {
  services.zerotierone.enable = true;
}
